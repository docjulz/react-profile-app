import React from "react";

export default function Header() {
    return (
        <>
            <h1>This is a test</h1>
        </>
    )
}