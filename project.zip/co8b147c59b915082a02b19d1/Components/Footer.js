import React from "react"

export default function Footer() {
    return (
        <>
            <h1>This is a test</h1>
        </>
    )
}