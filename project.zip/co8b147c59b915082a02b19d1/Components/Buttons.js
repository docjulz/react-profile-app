import React from "react"

export default function Buttons() {
    return (
        <>
            <h1>This is a test</h1>
        </>
    )
}